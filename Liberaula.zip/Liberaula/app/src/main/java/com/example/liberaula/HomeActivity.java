package com.example.liberaula;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity {
    Button btnLogout;
    Button btnNfc;
    FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //se premo il bottone di logout, ci fa il logout e ci torna sulla schermata di login
        btnLogout=findViewById(R.id.logout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intToLogin=new Intent(HomeActivity.this,LoginActivity.class);
                startActivity(intToLogin);
            }
        });


        //se clicco sul bottone "non sei ancora registrato?" mi porta alla schermata dove potro
        //registrarmi
        btnNfc=findViewById(R.id.NFC);
        btnNfc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intSignUp = new Intent(HomeActivity.this, NfcActivity.class);
                startActivity(intSignUp);
            }
        });

    }
}
